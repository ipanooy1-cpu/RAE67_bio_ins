from __future__ import annotations

import argparse
import math
import os
import queue
import threading
import time
from dataclasses import dataclass
from dataclasses import replace as replace_dataclass
from pathlib import Path
from typing import Any, Callable

from tools.servo_calibration_gui.tcl_bootstrap import prepare_tcl_runtime

prepare_tcl_runtime()

import tkinter as tk
from tkinter import scrolledtext, ttk

from .camera import CameraMailbox
from .camera_discovery import CameraChoice, choose_camera, discover_cameras
from .config import RuntimeConfig, load_runtime_config
from .cpg_editor import CpgProfileEditor
from .devices import resolve_serial_port
from .history import RollingHistory
from .mapping import HardwareMapper
from .plot_widget import LinePlot
from .runtime import RobotRuntime, RuntimeCommand, RuntimeSnapshot, RuntimeState


APP_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = APP_DIR.parents[1]
DEFAULT_CONFIG_PATH = APP_DIR / "robot_config.json"
DEFAULT_MODEL_PATH = PROJECT_ROOT / "face_vision(maincpg)" / "models" / "face_landmarker.task"


@dataclass(frozen=True)
class UiProjection:
    can_connect: bool
    can_arm: bool
    can_center: bool
    can_start_cpg: bool
    can_stop_cpg: bool
    can_emergency: bool
    can_start_camera: bool
    can_stop_camera: bool


def project_ui(snapshot: RuntimeSnapshot, *, camera_running: bool) -> UiProjection:
    state = snapshot.state
    connected = state not in (RuntimeState.DISCONNECTED, RuntimeState.CLOSED)
    can_reconnect = state in (
        RuntimeState.DISCONNECTED,
        RuntimeState.FAULT,
        RuntimeState.EMERGENCY,
    )
    return UiProjection(
        can_connect=can_reconnect,
        can_arm=state is RuntimeState.CONNECTED,
        can_center=state is RuntimeState.ARMED,
        can_start_cpg=(
            state is RuntimeState.ARMED
            and snapshot.center_ready
            and camera_running
        ),
        can_stop_cpg=state in (RuntimeState.RUNNING, RuntimeState.STOPPING),
        can_emergency=connected,
        can_start_camera=not camera_running and state is not RuntimeState.CLOSED,
        can_stop_camera=camera_running,
    )


class RobotCpgApp:
    POLL_MS = 100

    def __init__(
        self,
        root: tk.Tk,
        config: RuntimeConfig,
        mapper: HardwareMapper,
        runtime: RobotRuntime,
        camera_mailbox: CameraMailbox,
        *,
        camera_factory: Callable[[int], Any] | None,
        mock_mode: bool,
        camera_discovery: Callable[[], list[CameraChoice]] | None = None,
    ) -> None:
        self.root = root
        self.config = config
        self.mapper = mapper
        self.runtime = runtime
        self.camera_mailbox = camera_mailbox
        self.camera_factory = camera_factory
        self.camera_discovery = camera_discovery or discover_cameras
        self.mock_mode = bool(mock_mode)
        self.camera_worker: Any | None = None
        self.camera_running = False
        self.closed = False
        self.closing = False
        self._camera_stop_requested = False
        self._poll_after_id: str | None = None
        self._last_snapshot_time = -math.inf
        self._last_preview_sequence = 0
        self._last_state: RuntimeState | None = None
        self._preview_photo = None
        self._camera_choices: list[CameraChoice] = []
        self._camera_scan_queue: queue.Queue[tuple[list[CameraChoice], str]] = queue.Queue()
        self._camera_scan_thread: threading.Thread | None = None

        self.servo_names = tuple(
            f"ID{servo_id} {config.servos[servo_id].name}"
            for servo_id in sorted(config.servos)
        )
        self.cpg_names = tuple(f"J{index}" for index in range(1, 5))
        self.servo_history = RollingHistory(self.servo_names, window_seconds=10.0)
        self.cpg_history = RollingHistory(self.cpg_names, window_seconds=10.0)

        self.state_var = tk.StringVar(value="DISCONNECTED")
        self.camera_var = tk.StringVar(value="Camera stopped")
        self.camera_choice_var = tk.StringVar(value="")
        self.emotion_var = tk.StringVar(value="Neutral")
        self.input_var = tk.StringVar(value="not_started")
        self.fault_var = tk.StringVar(value="")
        self.hormone_vars = {
            name: tk.DoubleVar(value=0.0) for name in ("Happy", "Sad", "Confused")
        }

        self._build_ui()
        if self.mock_mode:
            self._set_camera_choices(
                [CameraChoice(config.camera_index, f"Mock Camera (index {config.camera_index})")]
            )
            self.camera_var.set("Mock camera ready")
        else:
            self.root.after_idle(self._begin_camera_scan)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self._poll()

    def _build_ui(self) -> None:
        mode_label = "MOCK" if self.mock_mode else "REAL HARDWARE"
        self.root.title(f"Emotion Robotic Lamp — Camera CPG Control [{mode_label}]")
        self.root.geometry("1380x900")
        self.root.minsize(1120, 740)
        try:
            ttk.Style(self.root).theme_use("clam")
        except tk.TclError:
            pass

        outer = ttk.Frame(self.root, padding=8)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        controls = ttk.LabelFrame(outer, text="1) Hardware / Motion Control", padding=7)
        controls.grid(row=0, column=0, sticky="ew", pady=(0, 7))
        ttk.Label(controls, text=f"Port: {self.config.port}").grid(row=0, column=0, padx=4)
        ttk.Label(controls, text=f"Baud: {self.config.baud}").grid(row=0, column=1, padx=4)
        ttk.Label(controls, text="State:").grid(row=0, column=2, padx=(15, 2))
        ttk.Label(controls, textvariable=self.state_var, width=14).grid(row=0, column=3, padx=2)

        self.connect_button = ttk.Button(
            controls, text="CONNECT", command=lambda: self.runtime.submit(RuntimeCommand.CONNECT)
        )
        self.arm_button = ttk.Button(
            controls, text="ENABLE MOTION", command=lambda: self.runtime.submit(RuntimeCommand.ARM)
        )
        self.center_button = ttk.Button(
            controls, text="GO CENTER", command=lambda: self.runtime.submit(RuntimeCommand.CENTER)
        )
        self.start_cpg_button = ttk.Button(
            controls, text="START CPG", command=lambda: self.runtime.submit(RuntimeCommand.START_CPG)
        )
        self.stop_cpg_button = ttk.Button(
            controls, text="STOP → CENTER", command=lambda: self.runtime.submit(RuntimeCommand.STOP_CPG)
        )
        buttons = (
            self.connect_button, self.arm_button, self.center_button,
            self.start_cpg_button, self.stop_cpg_button,
        )
        for column, button in enumerate(buttons, start=4):
            button.grid(row=0, column=column, padx=3, pady=2)

        self.emergency_button = tk.Button(
            controls,
            text="EMERGENCY\nTORQUE OFF",
            command=self._emergency,
            background="#c41414",
            foreground="white",
            activebackground="#8d0000",
            activeforeground="white",
            font=("TkDefaultFont", 11, "bold"),
            width=18,
            height=2,
        )
        self.emergency_button.grid(row=0, column=9, rowspan=2, padx=(12, 2), sticky="e")
        controls.columnconfigure(9, weight=1)
        ttk.Label(
            controls,
            text="STOP CPG กลับ Center | EMERGENCY ตัด Torque ทันทีและไม่ขยับกลับ",
            foreground="#a55a00",
        ).grid(row=1, column=0, columnspan=9, sticky="w", padx=4, pady=(4, 0))

        camera_and_status = ttk.Frame(outer)
        camera_and_status.grid(row=1, column=0, sticky="ew", pady=(0, 7))
        camera_and_status.columnconfigure(1, weight=1)

        camera_frame = ttk.LabelFrame(camera_and_status, text="2) USB Camera", padding=6)
        camera_frame.grid(row=0, column=0, sticky="nw", padx=(0, 7))
        camera_frame.columnconfigure(0, weight=1)
        self.camera_combo = ttk.Combobox(
            camera_frame,
            textvariable=self.camera_choice_var,
            values=(),
            state="readonly",
            width=30,
        )
        self.camera_scan_button = ttk.Button(
            camera_frame, text="SCAN CAMERAS", command=self._begin_camera_scan
        )
        self.camera_combo.grid(row=0, column=0, sticky="ew", padx=(0, 3), pady=(0, 5))
        self.camera_scan_button.grid(row=0, column=1, sticky="ew", padx=(3, 0), pady=(0, 5))
        self.preview_label = tk.Label(
            camera_frame, text="Camera preview", width=44, height=14,
            background="#101010", foreground="#d0d0d0",
        )
        self.preview_label.grid(row=1, column=0, columnspan=2)
        self.camera_start_button = ttk.Button(camera_frame, text="START CAMERA", command=self._start_camera)
        self.camera_stop_button = ttk.Button(camera_frame, text="STOP CAMERA", command=self._stop_camera)
        self.camera_start_button.grid(row=2, column=0, sticky="ew", pady=4, padx=(0, 2))
        self.camera_stop_button.grid(row=2, column=1, sticky="ew", pady=4, padx=(2, 0))
        ttk.Label(camera_frame, textvariable=self.camera_var).grid(row=3, column=0, columnspan=2, sticky="w")

        status_frame = ttk.LabelFrame(camera_and_status, text="3) Emotion / Hormone / Fault", padding=8)
        status_frame.grid(row=0, column=1, sticky="nsew")
        ttk.Label(status_frame, text="Emotion", font=("TkDefaultFont", 10, "bold")).grid(row=0, column=0, sticky="w")
        ttk.Label(status_frame, textvariable=self.emotion_var, font=("TkDefaultFont", 18, "bold")).grid(row=0, column=1, sticky="w", padx=10)
        ttk.Label(status_frame, text="Input status").grid(row=1, column=0, sticky="w")
        ttk.Label(status_frame, textvariable=self.input_var).grid(row=1, column=1, sticky="w", padx=10)
        for row, name in enumerate(("Happy", "Sad", "Confused"), start=2):
            ttk.Label(status_frame, text=f"H {name}").grid(row=row, column=0, sticky="w", pady=2)
            ttk.Progressbar(
                status_frame, variable=self.hormone_vars[name], maximum=1.0, length=300
            ).grid(row=row, column=1, sticky="ew", padx=10)
        ttk.Label(status_frame, text="FAULT", foreground="#b00000").grid(row=5, column=0, sticky="nw", pady=(8, 0))
        ttk.Label(status_frame, textvariable=self.fault_var, foreground="#b00000", wraplength=650).grid(
            row=5, column=1, sticky="w", padx=10, pady=(8, 0)
        )
        status_frame.columnconfigure(1, weight=1)

        notebook = ttk.Notebook(outer)
        notebook.grid(row=2, column=0, sticky="nsew")
        graph_tab = ttk.Frame(notebook, padding=6)
        servo_tab = ttk.Frame(notebook, padding=6)
        notebook.add(graph_tab, text="Live Graphs")
        notebook.add(servo_tab, text="Servo Feedback / Log")
        settings_tab = ttk.Frame(notebook, padding=6)
        notebook.add(settings_tab, text="CPG Settings")
        self.cpg_editor = CpgProfileEditor(settings_tab, runtime=self.runtime, logger=self._write_log)
        self.cpg_editor.pack(fill="both", expand=True)
        graph_tab.columnconfigure(0, weight=1)
        graph_tab.columnconfigure(1, weight=1)
        graph_tab.rowconfigure(0, weight=1)
        self.servo_plot = LinePlot(
            graph_tab,
            title="Servo Feedback — absolute joint angle (degrees)",
            names=self.servo_names,
        )
        self.cpg_plot = LinePlot(
            graph_tab,
            title="Main CPG Output — J1–J4 command (degrees)",
            names=self.cpg_names,
        )
        self.servo_plot.grid(row=0, column=0, sticky="nsew", padx=(0, 3))
        self.cpg_plot.grid(row=0, column=1, sticky="nsew", padx=(3, 0))
        ttk.Label(
            graph_tab,
            text=(f"Direct drive 1:1 · Center=90° · 1° ≈ {1 / self.config.nominal_degrees_per_count * self.config.cpg_hardware_scale:.2f} raw "
                  f"(scale={self.config.cpg_hardware_scale:g}) · limit ±{self.config.max_offset_raw} raw · physical feedback remains authoritative."),
            foreground="#a55a00",
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))

        columns = ("id", "joint", "raw", "angle", "target", "speed", "moving", "torque")
        self.servo_tree = ttk.Treeview(servo_tab, columns=columns, show="headings", height=5)
        headings = {
            "id": "ID", "joint": "Joint", "raw": "Raw", "angle": "Absolute ° (nominal)",
            "target": "Target raw", "speed": "Speed", "moving": "Moving", "torque": "Torque",
        }
        for name in columns:
            self.servo_tree.heading(name, text=headings[name])
            self.servo_tree.column(name, width=110 if name != "joint" else 150, anchor="center")
        self.servo_tree.pack(fill="x")
        for servo_id in sorted(self.config.servos):
            servo = self.config.servos[servo_id]
            self.servo_tree.insert(
                "", "end", iid=str(servo_id),
                values=(servo_id, servo.name, "—", "—", servo.center, "—", "—", "OFF"),
            )
        self.log_box = scrolledtext.ScrolledText(servo_tab, height=13, state="disabled")
        self.log_box.pack(fill="both", expand=True, pady=(7, 0))

    def _poll(self) -> None:
        if self.closed or self.closing:
            return
        snapshot = self.runtime.latest_snapshot()
        self._update_from_snapshot(snapshot)
        self._poll_camera_scan()
        self._poll_camera()
        self._apply_projection(project_ui(snapshot, camera_running=self.camera_running))
        self.cpg_editor.set_editable(
            not self.closing and snapshot.state in (
                RuntimeState.DISCONNECTED, RuntimeState.CONNECTED, RuntimeState.ARMED
            )
        )
        self._poll_after_id = self.root.after(self.POLL_MS, self._poll)

    def _update_from_snapshot(self, snapshot: RuntimeSnapshot) -> None:
        self.state_var.set(snapshot.state.value)
        self.emotion_var.set(snapshot.emotion)
        self.input_var.set(snapshot.input_status)
        self.fault_var.set(snapshot.fault_text)
        for name, variable in self.hormone_vars.items():
            variable.set(float(snapshot.hormones.get(name, 0.0)))
        if snapshot.state is not self._last_state:
            self._write_log(f"State → {snapshot.state.value}")
            self._last_state = snapshot.state

        if snapshot.timestamp > self._last_snapshot_time:
            if set(snapshot.feedback_raw) == set(self.config.servos):
                absolute = self.mapper.feedback_absolute_deg(snapshot.feedback_raw)
                self.servo_history.append(
                    snapshot.timestamp,
                    {
                        self.servo_names[index]: absolute[servo_id]
                        for index, servo_id in enumerate(sorted(self.config.servos))
                    },
                )
            self.cpg_history.append(
                snapshot.timestamp,
                {name: snapshot.cpg_deg[index] for index, name in enumerate(self.cpg_names)},
            )
            self._last_snapshot_time = snapshot.timestamp

        now = max(0.0, time.monotonic())
        self.servo_plot.draw(self.servo_history.series(now), now=now, y_range=(60.0, 120.0))
        self.cpg_plot.draw(self.cpg_history.series(now), now=now, y_range=(60.0, 120.0))
        angles = (
            self.mapper.feedback_absolute_deg(snapshot.feedback_raw)
            if set(snapshot.feedback_raw) == set(self.config.servos)
            else {}
        )
        for servo_id in sorted(self.config.servos):
            servo = self.config.servos[servo_id]
            raw = snapshot.feedback_raw.get(servo_id, "—")
            angle = f"{angles[servo_id]:.2f}" if servo_id in angles else "—"
            target = snapshot.target_raw.get(servo_id, servo.center)
            speed = snapshot.feedback_speed.get(servo_id, "—")
            moving = int(snapshot.feedback_moving.get(servo_id, False)) if servo_id in snapshot.feedback_moving else "—"
            torque = "ON" if snapshot.feedback_torque.get(servo_id, False) else "OFF"
            self.servo_tree.item(
                str(servo_id),
                values=(servo_id, servo.name, raw, angle, target, speed, moving, torque),
            )

    def _poll_camera(self) -> None:
        packet = self.camera_mailbox.latest_after(self._last_preview_sequence)
        if packet is None:
            if self.camera_worker is not None and not self.camera_worker.is_alive():
                if self._camera_stop_requested:
                    self._complete_camera_stop()
                else:
                    self.camera_running = False
                    self.camera_worker = None
            return
        self._last_preview_sequence = packet.sequence
        if packet.error:
            if packet.error == "camera stopped":
                self.camera_var.set("Camera stopped")
            else:
                self.camera_var.set(f"Camera fault: {packet.error}")
                self._write_log(self.camera_var.get())
            owner_alive = bool(
                self.camera_worker is not None and self.camera_worker.is_alive()
            )
            self.camera_running = owner_alive
            if not owner_alive:
                self.camera_worker = None
            return
        self.camera_var.set("Camera running")
        if packet.preview_rgb is not None:
            self._show_preview(packet.preview_rgb)
        if (
            self._camera_stop_requested
            and self.camera_worker is not None
            and not self.camera_worker.is_alive()
        ):
            self._complete_camera_stop()

    def _show_preview(self, preview_rgb: Any) -> None:
        try:
            from PIL import Image, ImageTk

            image = preview_rgb if isinstance(preview_rgb, Image.Image) else Image.fromarray(preview_rgb)
            photo = ImageTk.PhotoImage(image=image)
            self._preview_photo = photo
            self.preview_label.configure(image=photo, text="", width=0, height=0)
        except Exception as exc:
            self.camera_var.set(f"Preview unavailable: {exc}")

    def _apply_projection(self, projection: UiProjection) -> None:
        self._set_enabled(self.connect_button, projection.can_connect)
        self._set_enabled(self.arm_button, projection.can_arm)
        self._set_enabled(self.center_button, projection.can_center)
        self._set_enabled(self.start_cpg_button, projection.can_start_cpg)
        self._set_enabled(self.stop_cpg_button, projection.can_stop_cpg)
        scan_active = self._camera_scan_thread is not None
        camera_owner = self.camera_worker is not None
        selection_unlocked = not scan_active and not camera_owner and not self.closing
        can_start_camera = (
            projection.can_start_camera
            and selection_unlocked
            and self._selected_camera_index() is not None
        )
        self._set_enabled(self.camera_start_button, can_start_camera)
        self._set_enabled(self.camera_stop_button, projection.can_stop_camera)
        self._set_enabled(self.camera_scan_button, selection_unlocked)
        self.camera_combo.configure(state="readonly" if selection_unlocked else "disabled")
        self.emergency_button.configure(state="normal" if projection.can_emergency else "disabled")

    @staticmethod
    def _set_enabled(widget: ttk.Widget, enabled: bool) -> None:
        widget.state(("!disabled",) if enabled else ("disabled",))

    def _start_camera(self) -> None:
        if self.closed or self.closing:
            self.camera_var.set("Camera start rejected during shutdown")
            return
        if self._camera_scan_thread is not None:
            self.camera_var.set("Wait for camera scan to finish")
            return
        if self.camera_running or self.camera_worker is not None:
            self.camera_var.set("Camera cleanup in progress; wait before restart")
            return
        if self.camera_factory is None:
            self.camera_var.set("Camera factory is not configured")
            return
        camera_index = self._selected_camera_index()
        if camera_index is None:
            self.camera_var.set("No usable camera selected; press SCAN CAMERAS")
            return
        try:
            self.camera_worker = self.camera_factory(camera_index)
            self.camera_worker.start()
            self._camera_stop_requested = False
            self.camera_running = True
            self.camera_var.set("Camera starting…")
            self._write_log("Camera start requested")
        except Exception as exc:
            self.camera_running = False
            self.camera_var.set(f"Camera start failed: {exc}")

    def _begin_camera_scan(self) -> None:
        if self.closed or self.closing or self.camera_worker is not None:
            return
        if self.mock_mode:
            self._set_camera_choices(
                [
                    CameraChoice(
                        self.config.camera_index,
                        f"Mock Camera (index {self.config.camera_index})",
                    )
                ]
            )
            self.camera_var.set("Mock camera ready")
            return
        if self._camera_scan_thread is not None and self._camera_scan_thread.is_alive():
            return

        self.camera_var.set("Scanning camera indices 0-9...")
        self._set_enabled(self.camera_scan_button, False)
        self.camera_combo.configure(state="disabled")
        self._set_enabled(self.camera_start_button, False)

        def scan() -> None:
            try:
                self._camera_scan_queue.put((list(self.camera_discovery()), ""))
            except Exception as exc:
                self._camera_scan_queue.put(([], str(exc)))

        self._camera_scan_thread = threading.Thread(
            target=scan, name="camera-discovery", daemon=True
        )
        self._camera_scan_thread.start()

    def _poll_camera_scan(self) -> None:
        try:
            choices, error = self._camera_scan_queue.get_nowait()
        except queue.Empty:
            return
        self._camera_scan_thread = None
        if self.closed or self.closing:
            return
        if error:
            self._set_camera_choices([])
            self.camera_var.set(f"Camera scan failed: {error}")
            return
        self._set_camera_choices(choices)
        if choices:
            self.camera_var.set(f"Found {len(choices)} usable camera(s)")
        else:
            self.camera_var.set("No usable camera found at indices 0-9")

    def _set_camera_choices(self, choices: list[CameraChoice]) -> None:
        previous = self._selected_camera_index()
        preferred = self.config.camera_index if previous is None else previous
        self._camera_choices = list(choices)
        labels = tuple(choice.label for choice in self._camera_choices)
        self.camera_combo.configure(values=labels)
        selected = choose_camera(self._camera_choices, preferred)
        self.camera_choice_var.set("" if selected is None else selected.label)

    def _selected_camera_index(self) -> int | None:
        selected_label = self.camera_choice_var.get()
        for choice in self._camera_choices:
            if choice.label == selected_label:
                return choice.index
        return None

    def _stop_camera(self) -> None:
        if self.camera_worker is not None:
            self._camera_stop_requested = True
            if not self.camera_worker.stop(timeout=0.0):
                self.camera_running = True
                self.camera_var.set("Camera stopping...")
                return
        self._complete_camera_stop()

    def _complete_camera_stop(self) -> None:
        self.camera_worker = None
        self.camera_running = False
        self._camera_stop_requested = False
        self.camera_mailbox.publish(captured_at=time.monotonic(), error="camera stopped")
        self.camera_var.set("Camera stopped")
        self._write_log("Camera stopped")

    def _emergency(self) -> None:
        self.runtime.request_emergency()
        self._write_log("EMERGENCY requested — Torque Off")

    def _write_log(self, message: str) -> None:
        self.log_box.configure(state="normal")
        self.log_box.insert("end", message + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def close(self) -> None:
        if self.closed or self.closing:
            return
        self.closing = True
        self.runtime.request_emergency()
        self._set_enabled(self.camera_start_button, False)
        self._set_enabled(self.camera_stop_button, False)
        self._set_enabled(self.camera_scan_button, False)
        self.camera_combo.configure(state="disabled")
        self.cpg_editor.set_editable(False)
        if self._poll_after_id is not None:
            try:
                self.root.after_cancel(self._poll_after_id)
            except tk.TclError:
                pass
            self._poll_after_id = None
        self.state_var.set("SHUTTING DOWN - TORQUE OFF")
        self._write_log("Shutdown requested - waiting for robot Torque Off")
        self._poll_shutdown()

    def _poll_shutdown(self) -> None:
        if not self.runtime.close(timeout=0.0):
            snapshot = self.runtime.latest_snapshot()
            self._update_from_snapshot(snapshot)
            self._poll_after_id = self.root.after(self.POLL_MS, self._poll_shutdown)
            return
        if self.camera_worker is not None:
            self._camera_stop_requested = True
            if not self.camera_worker.stop(timeout=0.0):
                self.camera_var.set("Robot safe; waiting for camera to stop...")
                self._poll_after_id = self.root.after(self.POLL_MS, self._poll_shutdown)
                return
            self._complete_camera_stop()
        self.closed = True
        if self._poll_after_id is not None:
            try:
                self.root.after_cancel(self._poll_after_id)
            except tk.TclError:
                pass
            self._poll_after_id = None
        try:
            self.root.destroy()
        except tk.TclError:
            pass


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="USB camera + main CPG + SCS15 control GUI")
    parser.add_argument("--mock", action="store_true", help="run without camera or Servo hardware")
    parser.add_argument("--smoke-test", action="store_true", help="construct and close the GUI")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG_PATH)
    parser.add_argument("--port", default=None, help="COM8, /dev/ttyUSB0, or AUTO")
    parser.add_argument("--baud", type=int, default=None)
    parser.add_argument("--camera-index", type=int, default=None)
    parser.add_argument("--model-path", type=Path, default=DEFAULT_MODEL_PATH)
    parser.add_argument("--cpg-profile", type=Path, default=None,
                        help="editable CPG JSON path (defaults to tools/robot_cpg_gui/cpg_profile.json)")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    config = load_runtime_config(args.config)
    requested_port = args.port if args.port is not None else config.port
    baud = args.baud if args.baud is not None else config.baud
    camera_index = args.camera_index if args.camera_index is not None else config.camera_index

    mailbox = CameraMailbox()
    from .maincpg_adapter import MainCpgAdapter

    from .cpg_profile import DEFAULT_PROFILE_PATH
    cpg_adapter = MainCpgAdapter(
        start_time=time.monotonic(), mailbox=mailbox,
        profile_path=args.cpg_profile or DEFAULT_PROFILE_PATH,
        loop_hz=config.loop_hz, allow_defaults=args.mock,
    )
    mapper = HardwareMapper(config)
    if args.mock:
        from tools.servo_calibration_gui.bus import MockServoBus
        from .mock_components import MockCameraWorker

        bus = MockServoBus({servo_id: servo.center for servo_id, servo in config.servos.items()})
        camera_factory = lambda _camera_index: MockCameraWorker(mailbox)
        config = replace_dataclass(config, port="MOCK", baud=baud, camera_index=camera_index)
    else:
        from tools.servo_calibration_gui.feetech_bus import FeetechBus
        from .camera import UsbCameraWorker

        selected_port = resolve_serial_port(requested_port)
        config = replace_dataclass(
            config, port=selected_port, baud=baud, camera_index=camera_index
        )
        mapper = HardwareMapper(config)
        bus = FeetechBus(config.port, config.baud)

        def camera_factory(selected_camera_index: int):
            if not args.model_path.is_file():
                raise FileNotFoundError(f"MediaPipe model not found: {args.model_path}")
            return UsbCameraWorker(
                str(args.model_path), mailbox, camera_index=selected_camera_index
            )

    runtime = RobotRuntime(config, mapper, bus, cpg_adapter)
    runtime.start()
    root = tk.Tk()
    if args.smoke_test:
        root.withdraw()
    app = RobotCpgApp(
        root,
        config,
        mapper,
        runtime,
        mailbox,
        camera_factory=camera_factory,
        mock_mode=args.mock,
    )
    if args.smoke_test:
        root.update_idletasks()
        app.close()
        deadline = time.monotonic() + 3.0
        while not app.closed and time.monotonic() < deadline:
            try:
                root.update()
            except tk.TclError:
                break
            time.sleep(0.01)
        if not app.closed:
            raise RuntimeError("smoke-test shutdown did not complete")
        print("Integrated CPG GUI smoke test passed")
        return 0
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

