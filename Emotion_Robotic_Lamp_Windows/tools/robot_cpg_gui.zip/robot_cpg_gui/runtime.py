from __future__ import annotations

import math
import queue
import threading
import time
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any

from .config import RuntimeConfig
from .mapping import HardwareMapper


class RuntimeState(str, Enum):
    DISCONNECTED = "DISCONNECTED"
    CONNECTED = "CONNECTED"
    ARMED = "ARMED"
    CENTERING = "CENTERING"
    RUNNING = "RUNNING"
    STOPPING = "STOPPING"
    FAULT = "FAULT"
    EMERGENCY = "EMERGENCY"
    CLOSED = "CLOSED"


class RuntimeCommand(str, Enum):
    CONNECT = "connect"
    ARM = "arm"
    CENTER = "center"
    START_CPG = "start_cpg"
    STOP_CPG = "stop_cpg"
    DISCONNECT = "disconnect"


@dataclass(frozen=True)
class RuntimeSnapshot:
    timestamp: float
    state: RuntimeState
    feedback_raw: dict[int, int]
    feedback_speed: dict[int, int]
    feedback_moving: dict[int, bool]
    feedback_torque: dict[int, bool]
    cpg_deg: tuple[float, float, float, float]
    target_raw: dict[int, int]
    hormones: dict[str, float]
    emotion: str
    input_status: str
    fault_text: str
    torque_off_verified: bool
    center_ready: bool = False


class RobotRuntime:
    POSITION_TOLERANCE = 8
    POSITION_TIMEOUT = 5.0

    def __init__(self, config: RuntimeConfig, mapper: HardwareMapper, bus: Any, cpg_source: Any) -> None:
        self.config = config
        self.mapper = mapper
        self.bus = bus
        self.cpg_source = cpg_source
        self._commands: queue.Queue[RuntimeCommand] = queue.Queue()
        self._emergency = threading.Event()
        self._emergency_pending = threading.Event()
        self._motion_gate = threading.RLock()
        self._control_lock = threading.RLock()  # serialize profile swap with control steps
        self._close_requested = threading.Event()
        self._worker_stopped = threading.Event()
        self._snapshot_lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._bus_open = False
        self._poll_id = 0
        self._motion_deadline: float | None = None
        centers = {servo_id: servo.center for servo_id, servo in config.servos.items()}
        self._snapshot = RuntimeSnapshot(
            timestamp=0.0,
            state=RuntimeState.DISCONNECTED,
            feedback_raw={},
            feedback_speed={},
            feedback_moving={},
            feedback_torque={},
            cpg_deg=(90.0, 90.0, 90.0, 90.0),
            target_raw=centers,
            hormones={"Happy": 0.0, "Sad": 0.0, "Confused": 0.0},
            emotion="Neutral",
            input_status="not_started",
            fault_text="",
            torque_off_verified=False,
            center_ready=False,
        )

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._worker_stopped.clear()
        self._thread = threading.Thread(target=self._run_loop, name="robot-runtime", daemon=True)
        self._thread.start()

    def submit(self, command: RuntimeCommand | str) -> None:
        selected = command if isinstance(command, RuntimeCommand) else RuntimeCommand(command)
        self._commands.put(selected)

    def request_emergency(self) -> None:
        self._emergency_pending.set()
        with self._motion_gate:
            self._emergency.set()

    @property
    def is_stopped(self) -> bool:
        if self._thread is None:
            return self.latest_snapshot().state is RuntimeState.CLOSED
        return not self._thread.is_alive()

    def latest_snapshot(self) -> RuntimeSnapshot:
        with self._snapshot_lock:
            snapshot = self._snapshot
            return replace(
                snapshot,
                feedback_raw=dict(snapshot.feedback_raw),
                feedback_speed=dict(snapshot.feedback_speed),
                feedback_moving=dict(snapshot.feedback_moving),
                feedback_torque=dict(snapshot.feedback_torque),
                target_raw=dict(snapshot.target_raw),
                hormones=dict(snapshot.hormones),
            )

    def apply_cpg_profile(self, profile: dict) -> None:
        """Prepare, validate, persist and swap only with motion safely stopped.

        The control lock prevents a queued START/STOP/CENTER command from
        interleaving with the transaction. It never writes to a Servo bus.
        """
        import os
        import tempfile
        from .cpg_profile import save_profile_atomic
        with self._control_lock:
            if self._close_requested.is_set() or self.latest_snapshot().state not in (
                RuntimeState.DISCONNECTED, RuntimeState.CONNECTED, RuntimeState.ARMED
            ):
                raise RuntimeError("Stop CPG and wait until motion is settled before applying a profile")
            if not hasattr(self.cpg_source, "prepare_profile"):
                raise RuntimeError("CPG source does not support profiles")
            now = time.monotonic()
            ready = self.cpg_source.prepare_profile(profile, start_time=now)
            path = self.cpg_source.profile_path
            prior_bytes = path.read_bytes() if path.exists() else None
            # Source validation & controller construction finish BEFORE writing.
            save_profile_atomic(profile, path, dt=self.cpg_source.dt)
            try:
                self.cpg_source.install_prepared(ready)
            except Exception:
                # Unexpected swap failure: restore previous bytes atomically.
                if prior_bytes is None:
                    path.unlink(missing_ok=True)
                else:
                    temporary = None
                    try:
                        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".cpg-restore-", delete=False) as handle:
                            temporary = handle.name
                            handle.write(prior_bytes)
                            handle.flush()
                            os.fsync(handle.fileno())
                        os.replace(temporary, path)
                        temporary = None
                    finally:
                        if temporary:
                            os.unlink(temporary)
                raise

    def process_once(self, now: float | None = None) -> None:
        with self._control_lock:
            self._process_once_locked(now)

    def _process_once_locked(self, now: float | None = None) -> None:
        timestamp = time.monotonic() if now is None else float(now)
        if self.latest_snapshot().state is RuntimeState.CLOSED:
            return
        if self._emergency_pending.is_set() or self._emergency.is_set():
            self._process_emergency(timestamp)
            return

        try:
            state = self.latest_snapshot().state
            if state in (RuntimeState.FAULT, RuntimeState.EMERGENCY):
                try:
                    command = self._commands.get_nowait()
                except queue.Empty:
                    return
                self._handle_command(command, timestamp)
                return
            frame = self._sample_cpg(timestamp)
            self._checkpoint_emergency(timestamp)
            try:
                command = self._commands.get_nowait()
            except queue.Empty:
                command = None
            if command is not None:
                before = self.latest_snapshot().state
                self._handle_command(command, timestamp)
                if (command is RuntimeCommand.START_CPG
                    and before is RuntimeState.ARMED
                    and self.latest_snapshot().state is RuntimeState.RUNNING
                    and hasattr(self.cpg_source, "begin_motion")):
                    self.cpg_source.begin_motion(timestamp)
                    frame = self._sample_cpg(timestamp)

            state = self.latest_snapshot().state
            if state is RuntimeState.RUNNING:
                self._run_cpg_tick(frame, timestamp)
            elif state in (RuntimeState.CENTERING, RuntimeState.STOPPING):
                self._finish_positioning(timestamp)
            elif state is RuntimeState.ARMED:
                self._monitor_armed(timestamp)
        except _EmergencyAbort:
            return
        except Exception as exc:
            self._enter_fault(timestamp, str(exc))

    def close(self, timeout: float = 3.0) -> bool:
        if self.latest_snapshot().state is RuntimeState.CLOSED:
            return self.is_stopped
        self._close_requested.set()
        self.request_emergency()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=timeout)
            return not self._thread.is_alive() and self.latest_snapshot().state is RuntimeState.CLOSED
        self.process_once(time.monotonic())
        return self.latest_snapshot().state is RuntimeState.CLOSED

    def _run_loop(self) -> None:
        period = 1.0 / self.config.loop_hz
        next_tick = time.monotonic()
        try:
            while not self._worker_stopped.is_set():
                now = time.monotonic()
                self.process_once(now)
                if self.latest_snapshot().state is RuntimeState.CLOSED:
                    break
                next_tick += period
                if next_tick < time.monotonic():
                    next_tick = time.monotonic()
                self._worker_stopped.wait(max(0.0, next_tick - time.monotonic()))
        finally:
            self._worker_stopped.set()

    def _handle_command(self, command: RuntimeCommand, now: float) -> None:
        state = self.latest_snapshot().state
        if state in (RuntimeState.FAULT, RuntimeState.EMERGENCY) and command not in (
            RuntimeCommand.CONNECT,
            RuntimeCommand.DISCONNECT,
        ):
            return
        if command is RuntimeCommand.CONNECT:
            if state in (RuntimeState.FAULT, RuntimeState.EMERGENCY):
                errors = self._attempt_torque_off()
                if errors:
                    previous = self.latest_snapshot().fault_text
                    current = "; ".join(errors)
                    self._update_snapshot(
                        timestamp=now,
                        state=state,
                        fault_text=(
                            previous + ("; " + current if current else "")
                            if previous else current
                        ),
                        torque_off_verified=False,
                    )
                    return
            self._connect(now)
        elif command is RuntimeCommand.ARM:
            if state is not RuntimeState.CONNECTED:
                self._update_snapshot(timestamp=now, fault_text="Connect before Enable Motion")
                return
            self._arm(now)
        elif command is RuntimeCommand.CENTER:
            if state is not RuntimeState.ARMED:
                self._update_snapshot(timestamp=now, fault_text="Center requires ARMED state")
                return
            self._command_center(now)
        elif command is RuntimeCommand.START_CPG:
            if state is not RuntimeState.ARMED:
                self._update_snapshot(timestamp=now, fault_text="Enable Motion before Start CPG")
                return
            if not self.latest_snapshot().center_ready:
                self._update_snapshot(
                    timestamp=now,
                    fault_text="Go Center successfully after Enable Motion before Start CPG",
                )
                return
            if not bool(getattr(self.cpg_source, "ready", False)):
                self._update_snapshot(timestamp=now, fault_text="Camera is not ready")
                return
            readings = self._read_all(now)
            self._validate_feedback(readings)
            self._require_torque_enabled(readings)
            self._store_feedback(readings, now)
            self._update_snapshot(
                timestamp=now, state=RuntimeState.RUNNING,
                fault_text="", center_ready=False,
            )
        elif command is RuntimeCommand.STOP_CPG:
            if state in (RuntimeState.RUNNING, RuntimeState.STOPPING):
                self._command_center(now, stopping=True)
        elif command is RuntimeCommand.DISCONNECT:
            errors = self._attempt_torque_off()
            if errors:
                self._update_snapshot(
                    timestamp=now, state=RuntimeState.FAULT,
                    fault_text="; ".join(errors), torque_off_verified=False,
                    center_ready=False,
                )
            else:
                self._close_bus(now, final_state=RuntimeState.DISCONNECTED)

    def _connect(self, now: float) -> None:
        if self._bus_open:
            self.bus.close()
            self._bus_open = False
        self.bus.open()
        self._bus_open = True
        missing = [servo_id for servo_id in sorted(self.config.servos) if not self.bus.ping(servo_id)]
        if missing:
            raise RuntimeError("missing Servo IDs: " + ", ".join(map(str, missing)))
        readings = self._read_all(now)
        self._validate_feedback(readings)
        if any(item.torque_enabled for item in readings.values()):
            raise RuntimeError("Torque is enabled at connect; use Emergency Torque Off and reconnect")
        self._store_feedback(readings, now)
        self._update_snapshot(
            timestamp=now, state=RuntimeState.CONNECTED, fault_text="",
            torque_off_verified=not any(item.torque_enabled for item in readings.values()),
            center_ready=False,
        )

    def _arm(self, now: float) -> None:
        readings = self._read_all(now)
        self._validate_feedback(readings)
        if any(item.torque_enabled for item in readings.values()):
            raise RuntimeError("Torque is already enabled; use Emergency Torque Off first")
        current = {servo_id: item.position for servo_id, item in readings.items()}
        self._checkpoint_emergency(now)
        self._motion_transaction(
            now, lambda: self.bus.sync_write_positions(current, self.config.speed)
        )
        for servo_id in sorted(self.config.servos):
            self._motion_transaction(
                now, lambda servo_id=servo_id: self.bus.set_torque(servo_id, True)
            )
        readings = self._read_all(now)
        self._require_torque_enabled(readings)
        self._store_feedback(readings, now)
        self._update_snapshot(
            timestamp=now, state=RuntimeState.ARMED, target_raw=current,
            fault_text="", torque_off_verified=False, center_ready=False,
        )

    def _sample_cpg(self, now: float) -> Any:
        frame = self.cpg_source.step(now)
        q_deg = tuple(float(value) for value in frame.q_deg)
        if len(q_deg) != 4 or not all(math.isfinite(value) for value in q_deg):
            raise ValueError("CPG returned invalid four-joint output")
        self._update_snapshot(
            timestamp=now,
            cpg_deg=q_deg,
            hormones=dict(frame.hormones),
            emotion=str(frame.emotion),
            input_status=str(frame.input_status),
        )
        return frame

    def _run_cpg_tick(self, frame: Any, now: float) -> None:
        targets = self.mapper.targets_from_cpg(frame.q_deg)
        readings = self._read_all(now)
        self._validate_feedback(readings)
        self._require_torque_enabled(readings)
        self._store_feedback(readings, now)
        self._motion_transaction(
            now, lambda: self.bus.sync_write_positions(targets, self.config.speed)
        )
        self._update_snapshot(
            timestamp=now,
            target_raw=targets,
            fault_text="",
        )

    def _command_center(self, now: float, *, stopping: bool = False) -> None:
        centers = {servo_id: servo.center for servo_id, servo in self.config.servos.items()}
        self._motion_transaction(
            now, lambda: self.bus.sync_write_positions(centers, self.config.speed)
        )
        self._motion_deadline = now + self.POSITION_TIMEOUT
        self._update_snapshot(
            timestamp=now,
            state=RuntimeState.STOPPING if stopping else RuntimeState.CENTERING,
            target_raw=centers, cpg_deg=(90.0, 90.0, 90.0, 90.0),
            emotion="Neutral", input_status="stopped" if stopping else "center",
            fault_text="", center_ready=False,
        )
        self._finish_positioning(now)

    def _finish_positioning(self, now: float) -> None:
        readings = self._read_all(now)
        self._validate_feedback(readings)
        self._require_torque_enabled(readings)
        self._store_feedback(readings, now)
        settled = all(
            not readings[servo_id].moving
            and abs(readings[servo_id].position - servo.center) <= self.POSITION_TOLERANCE
            for servo_id, servo in self.config.servos.items()
        )
        if settled:
            self._motion_deadline = None
            self._update_snapshot(
                timestamp=now, state=RuntimeState.ARMED,
                fault_text="", center_ready=True,
            )
        elif self._motion_deadline is not None and now >= self._motion_deadline:
            raise RuntimeError("center positioning timeout")

    def _monitor_armed(self, now: float) -> None:
        servo_ids = sorted(self.config.servos)
        servo_id = servo_ids[self._poll_id % len(servo_ids)]
        self._poll_id += 1
        feedback = self.bus.read_feedback(servo_id)
        self._checkpoint_emergency(now)
        self._validate_feedback({servo_id: feedback})
        self._require_torque_enabled({servo_id: feedback})
        self._store_feedback({servo_id: feedback}, now)

    def _enter_fault(self, now: float, message: str) -> None:
        self._drain_commands()
        errors = self._attempt_torque_off()
        combined = message if not errors else message + "; " + "; ".join(errors)
        self._update_snapshot(
            timestamp=now, state=RuntimeState.FAULT, fault_text=combined,
            torque_off_verified=not errors, center_ready=False,
        )

    def _attempt_torque_off(self) -> list[str]:
        errors: list[str] = []
        if not self._bus_open:
            return errors
        for servo_id in sorted(self.config.servos):
            try:
                self.bus.set_torque(servo_id, False)
            except Exception as exc:
                errors.append(f"ID {servo_id}: {exc}")
        readings: dict[int, Any] = {}
        for servo_id in sorted(self.config.servos):
            try:
                feedback = self.bus.read_feedback(servo_id)
                readings[servo_id] = feedback
                if feedback.torque_enabled:
                    errors.append(f"ID {servo_id}: torque still enabled")
            except Exception as exc:
                errors.append(f"ID {servo_id}: verify failed: {exc}")
        if readings:
            self._store_feedback(readings, self.latest_snapshot().timestamp)
        return errors

    def _close_bus(
        self, now: float, *, final_state: RuntimeState = RuntimeState.CLOSED
    ) -> None:
        if self._bus_open:
            self.bus.close()
            self._bus_open = False
        if final_state is RuntimeState.CLOSED:
            self._worker_stopped.set()
        self._update_snapshot(timestamp=now, state=final_state, center_ready=False)

    def _read_all(self, now: float | None = None) -> dict[int, Any]:
        readings: dict[int, Any] = {}
        for servo_id in sorted(self.config.servos):
            readings[servo_id] = self.bus.read_feedback(servo_id)
            if now is not None:
                self._checkpoint_emergency(now)
        return readings

    def _validate_feedback(self, readings: dict[int, Any]) -> None:
        for servo_id, feedback in readings.items():
            servo = self.config.servos[servo_id]
            if not servo.safe_min <= int(feedback.position) <= servo.safe_max:
                raise RuntimeError(
                    f"ID {servo_id} position {feedback.position} outside safe range "
                    f"{servo.safe_min}..{servo.safe_max}"
                )

    @staticmethod
    def _require_torque_enabled(readings: dict[int, Any]) -> None:
        disabled = [
            servo_id for servo_id, feedback in readings.items()
            if not bool(feedback.torque_enabled)
        ]
        if disabled:
            raise RuntimeError(
                "torque disabled unexpectedly for ID " + ", ".join(map(str, disabled))
            )

    def _store_feedback(self, readings: dict[int, Any], now: float) -> None:
        snapshot = self.latest_snapshot()
        raw = dict(snapshot.feedback_raw)
        speed = dict(snapshot.feedback_speed)
        moving = dict(snapshot.feedback_moving)
        torque = dict(snapshot.feedback_torque)
        for servo_id, item in readings.items():
            raw[servo_id] = int(item.position)
            speed[servo_id] = int(item.speed)
            moving[servo_id] = bool(item.moving)
            torque[servo_id] = bool(item.torque_enabled)
        self._update_snapshot(
            timestamp=now, feedback_raw=raw, feedback_speed=speed,
            feedback_moving=moving, feedback_torque=torque,
        )

    def _update_snapshot(self, **changes: Any) -> None:
        with self._snapshot_lock:
            self._snapshot = replace(self._snapshot, **changes)

    def _drain_commands(self) -> None:
        while True:
            try:
                self._commands.get_nowait()
            except queue.Empty:
                return

    def _checkpoint_emergency(self, now: float) -> None:
        if not (self._emergency_pending.is_set() or self._emergency.is_set()):
            return
        self._process_emergency(now)
        raise _EmergencyAbort

    def _motion_transaction(self, now: float, operation: Any) -> None:
        should_abort = False
        with self._motion_gate:
            if self._emergency_pending.is_set() or self._emergency.is_set():
                should_abort = True
            else:
                operation()
        if should_abort or self._emergency_pending.is_set() or self._emergency.is_set():
            self._checkpoint_emergency(now)

    def _process_emergency(self, now: float) -> None:
        self._emergency_pending.clear()
        self._emergency.clear()
        self._drain_commands()
        errors = self._attempt_torque_off()
        if self._close_requested.is_set() and not errors:
            try:
                self._close_bus(now, final_state=RuntimeState.CLOSED)
                return
            except Exception as exc:
                errors.append(f"serial close failed: {exc}")
        if self._close_requested.is_set() and errors:
            self._emergency_pending.set()
            self._emergency.set()
        previous = self.latest_snapshot().fault_text
        fault_text = "; ".join(errors)
        if previous and previous not in fault_text:
            fault_text = previous + ("; " + fault_text if fault_text else "")
        self._update_snapshot(
            timestamp=now,
            state=RuntimeState.EMERGENCY,
            fault_text=fault_text,
            torque_off_verified=not errors,
            center_ready=False,
        )


class _EmergencyAbort(Exception):
    pass

